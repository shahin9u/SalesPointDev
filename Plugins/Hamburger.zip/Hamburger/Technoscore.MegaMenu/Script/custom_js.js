jQuery(document).ready(function () {

    /*Menu Right Slide and Closed*/
    jQuery('.menu_icon .menu_btn').click(function () {
        jQuery('.main-navigation').addClass('open-right');
        jQuery('body').addClass('open_menu');
    });
    jQuery('.menu_close').click(function () {
        jQuery('.main-navigation').removeClass('open-right');
        jQuery('body').removeClass('open_menu');
    });


    /*Category Name as a Title in menu*/
    jQuery('#primary-menu > li > a > .menu-image-title').filter(function () {
        var catName = jQuery(this).text().trim();
        jQuery(this).parent().siblings('ul.sub-menu').attr('data-value', catName);
    });

    if (jQuery(window).width() > 767) {
        /*Submenu show hide and selected effect*/

        jQuery('.main-navigation ul.menu li.menu-item-has-children a').click(function () {

            if (jQuery(this).parent('.menu-item').hasClass('selected')) {
                jQuery(this).siblings('ul.sub-menu').fadeOut('slow');
                jQuery(this).parent('.menu-item').removeClass('selected');
                return;
            }

            jQuery('.main-navigation ul.menu li a').parent('.menu-item').removeClass('selected');
            jQuery('.main-navigation ul.menu li a').siblings('ul.sub-menu').fadeOut('slow');

            jQuery(this).parent('.menu-item').addClass('selected');
            jQuery(this).siblings('ul.sub-menu').fadeToggle('slow');
        });


        /*Two coloumn page height as text height*/
        jQuery(".content-column.full_width").each(function () {
            var height = jQuery(this).find('.one_half').first().outerHeight();
            jQuery(this).children('.content-column.one_half').css('height', height);
        });

        jQuery(window).resize(function () {
            var height = jQuery(this).find('.one_half').first().outerHeight();
            jQuery(this).children('.content-column.one_half').css('height', height);
        });
    }


    /*Auto Select Main Category if open sub category*/
    if (jQuery('.main-navigation ul.menu li.menu-item-has-children ul li.current-menu-item')) {

        var catCurrent = '.main-navigation ul.menu li.menu-item-has-children ul li.current-menu-item';
        jQuery(catCurrent).parents('.current-menu-parent').addClass('selected');
        jQuery(catCurrent).parents('.sub-menu').css('display', 'block');
    }


    /*Mobile slideup and down sub menues*/
    if (jQuery(window).width() <= 767) {
        jQuery('.main-navigation ul.menu li.menu-item-has-children a').click(function () {

            if (jQuery(this).parent('.menu-item').hasClass('selected')) {
                jQuery(this).siblings('ul.sub-menu').slideUp('slow');
                jQuery(this).parent('.menu-item').removeClass('selected');
                return;
            }

            if (jQuery(this).parent('.menu-item').hasClass('search_menu')) {
                jQuery('.main-navigation .menu-header-menu-container').animate({ scrollTop: jQuery('.main-navigation ul').height() }, 1000);
            } else {
                jQuery('.main-navigation .menu-header-menu-container').animate({ scrollTop: 0 }, 1000);
            }

            jQuery('.main-navigation ul.menu li a').parent('.menu-item').removeClass('selected');
            jQuery('.main-navigation ul.menu li a').siblings('ul.sub-menu').slideUp('slow');

            jQuery(this).parent('.menu-item').addClass('selected');
            jQuery(this).siblings('ul.sub-menu').slideDown('slow');

        });
    }  

    /*Zoom at detail page thumbnail arrow id more than three images*/
    var countList = jQuery('.thumbnails ul li').length;
    if (countList <= 3) {
        jQuery('.thumbnails').hover(function () {
            jQuery('.thumbnails #slider-prev').css({ "visibility": "hidden" });
            jQuery('.thumbnails #slider-next').css({ "visibility": "hidden" });
        });
    }

    /*Detail page Print option*/
    jQuery('.crunchify-print').click(function () {
        window.print();
    });

    /*Remove Extra P Tag from two column page*/
    jQuery('.two_col_page .entry-content > p').remove();


    /*View More Link after three post*/
    jQuery('.prev_post_content').children('.prev_post').each(function (i) {

        if (i > 2) {
            jQuery(this).addClass('disabled');
        }
    });

    /*Map close and open at mobile*/
    jQuery('.map_close a').click(function () {
        jQuery('.wpsl-gmap-canvas').toggleClass('close');
        jQuery(this).toggleClass('opentext');
        if (jQuery(this).hasClass('opentext')) {
            jQuery(this).text('Open Map');
        } else {
            jQuery(this).text('Close Map');
        }
    });


    /*More hare oprion*/
    jQuery('.share_next_post .crunchify-social .crunchify-share').hover(function () {
        jQuery('.more_share').show();
    }, function () {
        jQuery('.more_share').hide();
    });
    jQuery('.more_share').hover(function () {
        jQuery('.more_share').show();
    }, function () {
        jQuery('.more_share').hide();
    });

    /*setTimeout(function(){
      if (jQuery('.ajax_response p').length > 0) {
        jQuery('.ajax_response p').remove();
      }
    }, 5000)*/

});
